export interface SemanticVersion {
    major: string;
    minor: string;
    patch: string;
}