declare namespace NodeJS {
    export interface ProcessEnv {
        DOMAIN: string;
        PORT: number;
    }
}